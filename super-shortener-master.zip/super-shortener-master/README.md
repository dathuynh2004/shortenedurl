# Super-Shortened

A shortened web link with Nodejs. Shorten URLs using invisible spaces.

## Requirements
Run in localhost:
 - Install Nodejs
 - Install Npm
- Mongodb
## Installing
Install all dependencies:
 - Mongoose
 - Express
 - Qrcode
 - Svg-captcha
 - ...
```
$ npm install
```

You can then run the project on localhost with port 3000 or you can run the project right now on the heroku app

## Todos
 - Write MORE Tests
 - Add Night Mode